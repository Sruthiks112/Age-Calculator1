import React, { useState } from "react";
import "./App.css";


function App(){
  
  const [Name,setname]= useState("");
  const [Dob,setdob] = useState ("");

const handleInput=(e)=>{

  setname(e.target.value);
  setdob(e.target.value);

}

const updated=(e)=>{

  e.preventDefault();

  
  let today = new Date(),
      dob1= new Date(Dob),
      year= today.getFullYear() -  dob1.getFullYear();

      

      setdob(year);


//grouping

if(year<=20){

  const teens=[year];
  const teenlist=teens.map((teen)=>
  <li>{teen}</li>
  );

}
if(year>20 && year <=60){

  const adults=[year];
  const adultlist=adults.map((adult)=>
  <li>{adult}</li>
  );

}

if(year>60){

  const elders=[year];
  const elderlist=elders.map((elder)=>
  <li>{elder}</li>
  );

}


}



  return(
    <div className="header">

      <form  onSubmit={updated}>
            <p>Enter Name :</p> 
            <input type="text" onChange={handleInput}/>
            <p>Enter DOB :</p>
            <input type="date" onChange={handleInput} />
            <button>Submit</button>
      </form>
      <p>Your Age is {Dob}</p>
      </div>
    

  )

}


export default App;