import React from "react";

function suggestedProduct(){
return(
    <div>
        <h1>
            suggestedProduct is working
        </h1>
    </div>
)

}

export default suggestedProduct;