import React, { useState } from "react";
import "./App.css";


import SuggestedProducts from "./SuggestedProducts"
function App(){
  
        const [Name,setname]= useState("");  
        const [Dob,setdob] = useState ("");
        const [Age,setage] = useState ("");

           
        const [teens, setteens] = useState([]);
        const [adults, setadults] = useState([]);
        const [elders,setelders] = useState([]);

        
        const handleName=(e)=>{

            setname(e.target.value);
  
        }
        const handleAge=(e)=>{
            setdob(e.target.value);
        }

        const Updated=(e)=>{

            e.preventDefault();
            
            let today = new Date(),
            dob1= new Date(Dob),
            year= today.getFullYear() -  dob1.getFullYear();
            
           setage(year);

           //grouping

          if (year<=20){
            setteens([
              ...teens,
              {
                name1: Name,
                age1 : Age
              }
            ]);
          } 
          if (year>20 && year <60){
            setadults([
              ...adults,
              {
                name1: Name,
                age1 : Age
              }
            ]);
          } 
          if (year>=20){
            setelders([
              ...elders,
              {
                name1: Name,
                age1 : Age
              }
            ]);
          } 


         

    }

        return(
          <div>
              <div className="header">

                    <form  onSubmit={Updated}>
                    <p>Enter Name :</p> 
                    <input type="text" onChange={handleName} required/>
                    <p>Enter DOB :</p>
                    <input type="date" onChange={handleAge}  required/>
                    <button>Calculate Age</button>
                    </form>
                    
                    <p>{Age}</p>

                   
                    
              </div>
              <div className="content">
              <h1 className="centercontent">SuggestedProducts</h1>
              <SuggestedProducts age={Age}/>
              </div>    
          </div>
    

        );

}


export default App;