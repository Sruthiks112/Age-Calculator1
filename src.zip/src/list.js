export const teens =[
    {
        
        Title:<a href ="#">Product1</a>,
        Image:<img src="https://robohash.org/one" width="20%" height="20%"/>,
        content:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean auctor purus at quam tristique"
    },
    {
        Title:<a href ="#">Title2</a>,
        Image:<img src="https://robohash.org/2" width="20%" height="20%"/>,
        content:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean auctor purus at quam tristique"
    },
    {
        Title:<a href ="#">Title3</a>,
        Image:<img src="https://robohash.org/oe" width="20%" height="20%"/>,
        content:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean auctor purus at quam tristique" 

    }
];

export const adults =[
    {
        Title:<a href ="#">Title1</a>,
        Image:<img src="https://robohash.org/7" width="20%" height="20%"/>,
        content:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean auctor purus at quam tristique"

    },
    {
        Title:<a href ="#">Title1</a>,
        Image:<img src="https://robohash.org/3" width="20%" height="20%"/>,
        content:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean auctor purus at quam tristique"

    },
    {
        Title:<a href ="#">Title1</a>,
        Image:<img src="https://robohash.org/dr" width="20%" height="20%"/>,
        content:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean auctor purus at quam tristique"

    }
];

export const elders =[
    {
        Title:<a href ="#">Title1</a>,
        Image:<img src="https://robohash.org/oghe" width="20%" height="20%"/>,
        content:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean auctor purus at quam tristique" 

    },
    {
        Title:<a href ="#">Title1</a>,
        Image:<img src="https://robohash.org/oddfe" width="20%" height="20%"/>,
        content:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean auctor purus at quam tristque" 

    },
    {
        Title:<a href ="#">Title1</a>,
        Image:<img src="https://robohash.org/rtne" width="20%" height="20%"/>,
        content:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean auctor purus at quam tristique" 
        
    }
];